import Link from "next/link"
import Image from "next/image"
import {
  ArrowRight,
  Brain,
  Cpu,
  Layers,
  Map,
  Radar,
  ScanLine,
  Users,
} from "lucide-react"
import { Button } from "@/components/ui/button"

const features = [
  {
    icon: Brain,
    title: "DeepLabV3 + ResNet-50",
    description:
      "Fine-tuned deep learning model with mixed precision training and cosine LR scheduling.",
  },
  {
    icon: Layers,
    title: "Pixel-Level Classification",
    description:
      "Every pixel is classified into one of 10 terrain categories for fine-grained understanding.",
  },
  {
    icon: ScanLine,
    title: "10 Terrain Classes",
    description:
      "Detects open ground, vegetation, rocks, logs, and other natural obstacles in desert scenes.",
  },
  {
    icon: Radar,
    title: "Real-Time Inference",
    description:
      "FastAPI backend with GPU acceleration for instant segmentation results.",
  },
]

const useCases = [
  { icon: Map, label: "Autonomous Off-Road Navigation" },
  { icon: Cpu, label: "Robotics in Desert Environments" },
  { icon: Radar, label: "Search & Rescue Path Planning" },
  { icon: Layers, label: "Environmental Monitoring" },
]

export default function IntroPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Navigation */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 md:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="relative size-8 rounded-lg overflow-hidden border border-primary/30">
              <Image
                src="/images/mummy.webp"
                alt="Team Bears mascot"
                fill
                className="object-cover"
              />
            </div>
            <span className="text-sm font-semibold text-foreground tracking-tight">
              Team Bears
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-muted-foreground font-mono hidden sm:block">
              Startathon 2026
            </span>
            <Button asChild size="sm" className="h-8 text-xs font-semibold">
              <Link href="/segment">
                Launch Tool
                <ArrowRight className="size-3.5" />
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          {/* Subtle warm radial glow behind hero */}
          <div
            className="pointer-events-none absolute inset-0"
            aria-hidden="true"
          >
            <div className="absolute left-1/2 top-1/3 -translate-x-1/2 -translate-y-1/2 size-[600px] rounded-full bg-primary/8 blur-[120px]" />
          </div>

          <div className="relative max-w-6xl mx-auto px-4 md:px-6 pt-16 pb-20 md:pt-24 md:pb-28">
            <div className="flex flex-col items-center text-center gap-8">
              {/* Badge */}
              <div className="flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5">
                <Users className="size-3.5 text-primary" />
                <span className="text-xs font-medium text-primary">
                  Startathon &middot; Team Bears
                </span>
              </div>

              {/* Mascot Image */}
              <div className="relative w-48 h-48 md:w-56 md:h-56 rounded-2xl overflow-hidden border-2 border-primary/20 shadow-lg shadow-primary/10">
                <Image
                  src="/images/mummy.webp"
                  alt="Desert Mummy - Team Bears mascot for Startathon hackathon"
                  fill
                  className="object-cover"
                  priority
                />
                <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-foreground/5" />
              </div>

              {/* Title */}
              <div className="flex flex-col gap-3 max-w-2xl">
                <h1 className="text-3xl md:text-5xl font-bold text-foreground tracking-tight text-balance leading-tight">
                  Desert Semantic Segmentation AI
                </h1>
                <p className="text-base md:text-lg text-muted-foreground leading-relaxed text-pretty max-w-xl mx-auto">
                  A deep learning computer vision system for pixel-level terrain
                  classification in off-road desert environments.
                </p>
              </div>

              {/* CTA */}
              <div className="flex flex-col sm:flex-row items-center gap-3 mt-2">
                <Button
                  asChild
                  size="lg"
                  className="h-12 px-8 text-sm font-semibold"
                >
                  <Link href="/segment">
                    Try Segmentation Tool
                    <ArrowRight className="size-4" />
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  size="lg"
                  className="h-12 px-8 text-sm"
                >
                  <a href="#about">Learn More</a>
                </Button>
              </div>

              {/* Quick stats */}
              <div className="grid grid-cols-3 gap-6 md:gap-12 mt-4 pt-6 border-t border-border/50 w-full max-w-md">
                <div className="flex flex-col items-center gap-1">
                  <span className="text-2xl md:text-3xl font-bold text-foreground font-mono">
                    10
                  </span>
                  <span className="text-[11px] text-muted-foreground uppercase tracking-wider">
                    Classes
                  </span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <span className="text-2xl md:text-3xl font-bold text-foreground font-mono">
                    0.60
                  </span>
                  <span className="text-[11px] text-muted-foreground uppercase tracking-wider">
                    Val IoU
                  </span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <span className="text-2xl md:text-3xl font-bold text-foreground font-mono">
                    512
                  </span>
                  <span className="text-[11px] text-muted-foreground uppercase tracking-wider">
                    Resolution
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="border-t border-border bg-card/30">
          <div className="max-w-6xl mx-auto px-4 md:px-6 py-16 md:py-20">
            <div className="text-center mb-12">
              <h2 className="text-xl md:text-2xl font-bold text-foreground tracking-tight text-balance">
                What Makes This Special
              </h2>
              <p className="text-sm text-muted-foreground mt-2 max-w-md mx-auto text-pretty">
                Unlike traditional object detection, our system classifies every
                single pixel in the image.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {features.map((feature) => (
                <div
                  key={feature.title}
                  className="group rounded-xl border border-border bg-card p-5 flex gap-4 items-start hover:border-primary/30 transition-colors"
                >
                  <div className="flex items-center justify-center size-10 rounded-lg bg-primary/10 border border-primary/15 shrink-0">
                    <feature.icon className="size-5 text-primary" />
                  </div>
                  <div className="flex flex-col gap-1">
                    <h3 className="text-sm font-semibold text-foreground">
                      {feature.title}
                    </h3>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="border-t border-border">
          <div className="max-w-6xl mx-auto px-4 md:px-6 py-16 md:py-20">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-start">
              {/* Left: About text */}
              <div className="flex flex-col gap-6">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-primary">
                    About the Project
                  </span>
                  <h2 className="text-xl md:text-2xl font-bold text-foreground mt-2 tracking-tight text-balance">
                    Intelligent Terrain Understanding for the Real World
                  </h2>
                </div>
                <div className="flex flex-col gap-4 text-sm text-muted-foreground leading-relaxed">
                  <p>
                    Desert Semantic Segmentation AI uses a fine-tuned DeepLabV3
                    with ResNet-50 backbone to segment desert images into 10
                    distinct terrain classes such as open ground, vegetation,
                    rocks, logs, and other natural obstacles.
                  </p>
                  <p>
                    The model was trained on high-resolution desert imagery
                    (512x768) using mixed precision training, backbone freezing
                    with fine-tuning, cosine learning rate scheduling, and early
                    stopping -- achieving a validation IoU of ~0.60.
                  </p>
                  <p>
                    By combining deep learning with an interactive web interface,
                    this project demonstrates how AI can be deployed as a usable
                    real-world tool -- bridging the gap from model to API to web
                    application to end user.
                  </p>
                </div>
              </div>

              {/* Right: Use cases + System pipeline */}
              <div className="flex flex-col gap-6">
                <div className="rounded-xl border border-border bg-card p-5">
                  <h3 className="text-sm font-semibold text-foreground mb-4">
                    Applications
                  </h3>
                  <div className="flex flex-col gap-3">
                    {useCases.map((item) => (
                      <div
                        key={item.label}
                        className="flex items-center gap-3"
                      >
                        <div className="flex items-center justify-center size-8 rounded-md bg-primary/8 border border-primary/10">
                          <item.icon className="size-4 text-primary" />
                        </div>
                        <span className="text-sm text-foreground">
                          {item.label}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-xl border border-border bg-card p-5">
                  <h3 className="text-sm font-semibold text-foreground mb-4">
                    System Pipeline
                  </h3>
                  <div className="flex items-center gap-2 flex-wrap">
                    {[
                      "Upload Image",
                      "FastAPI Backend",
                      "DeepLabV3 Inference",
                      "Segmentation Mask",
                      "Overlay View",
                    ].map((step, i) => (
                      <div key={step} className="flex items-center gap-2">
                        <span className="text-xs font-medium text-foreground bg-secondary rounded-md px-2.5 py-1.5 whitespace-nowrap">
                          {step}
                        </span>
                        {i < 4 && (
                          <ArrowRight className="size-3 text-muted-foreground shrink-0" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-xl border border-primary/20 bg-primary/5 p-5">
                  <h3 className="text-sm font-semibold text-foreground mb-2">
                    Future Improvements
                  </h3>
                  <ul className="flex flex-col gap-1.5 text-xs text-muted-foreground">
                    <li>
                      <span className="text-primary mr-1.5">{">"}</span>
                      Test-time augmentation for higher IoU
                    </li>
                    <li>
                      <span className="text-primary mr-1.5">{">"}</span>
                      Lightweight model optimization for edge devices
                    </li>
                    <li>
                      <span className="text-primary mr-1.5">{">"}</span>
                      Deployment for real-time robotic systems
                    </li>
                    <li>
                      <span className="text-primary mr-1.5">{">"}</span>
                      Multi-model ensemble for improved accuracy
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Banner */}
        <section className="border-t border-border bg-card/30">
          <div className="max-w-6xl mx-auto px-4 md:px-6 py-14 md:py-16 text-center">
            <h2 className="text-xl md:text-2xl font-bold text-foreground tracking-tight text-balance">
              Ready to see it in action?
            </h2>
            <p className="text-sm text-muted-foreground mt-2 mb-6 max-w-md mx-auto text-pretty">
              Upload a desert terrain image and watch the AI classify every
              pixel in real time.
            </p>
            <Button
              asChild
              size="lg"
              className="h-12 px-10 text-sm font-semibold"
            >
              <Link href="/segment">
                Open Segmentation Tool
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-5">
        <div className="max-w-6xl mx-auto px-4 md:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="relative size-6 rounded-md overflow-hidden border border-primary/20">
              <Image
                src="/images/mummy.webp"
                alt=""
                fill
                className="object-cover"
              />
            </div>
            <p className="text-xs text-muted-foreground">
              <span className="text-foreground font-medium">Team Bears</span>
              {" "}&middot; Startathon 2026
            </p>
          </div>
          <p className="text-xs text-muted-foreground font-mono">
            DeepLabV3 ResNet-50 &middot; PyTorch &middot; FastAPI &middot;
            Next.js
          </p>
        </div>
      </footer>
    </div>
  )
}
