import { NextRequest, NextResponse } from "next/server"

const BACKEND_URL = process.env.BACKEND_URL || "http://localhost:8000"

export async function GET(request: NextRequest) {
  const path = request.nextUrl.searchParams.get("path")

  if (!path) {
    return NextResponse.json({ error: "Missing path parameter" }, { status: 400 })
  }

  try {
    const response = await fetch(`${BACKEND_URL}/${path}`)

    if (!response.ok) {
      return NextResponse.json(
        { error: `Image not found: ${response.status}` },
        { status: response.status }
      )
    }

    const buffer = await response.arrayBuffer()
    return new NextResponse(buffer, {
      headers: {
        "Content-Type": response.headers.get("Content-Type") || "image/png",
        "Cache-Control": "public, max-age=3600",
      },
    })
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to fetch image"
    return NextResponse.json({ error: message }, { status: 502 })
  }
}
