import Link from "next/link"
import Image from "next/image"
import { ArrowLeft } from "lucide-react"

export function AppHeader() {
  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 md:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link
            href="/"
            className="flex items-center justify-center size-8 rounded-lg bg-secondary border border-border text-muted-foreground hover:text-foreground hover:border-primary/30 transition-colors"
            aria-label="Back to home"
          >
            <ArrowLeft className="size-4" />
          </Link>
          <div className="flex items-center gap-2.5">
            <div className="relative size-8 rounded-lg overflow-hidden border border-primary/30">
              <Image
                src="/images/mummy.webp"
                alt=""
                fill
                className="object-cover"
              />
            </div>
            <div>
              <h1 className="text-sm font-semibold text-foreground tracking-tight">
                Desert Semantic Segmentation AI
              </h1>
              <p className="text-[11px] text-muted-foreground">
                Upload an off-road desert image to detect terrain classes
              </p>
            </div>
          </div>
        </div>
        <span className="text-[11px] text-muted-foreground font-mono hidden sm:block">
          Team Bears &middot; Startathon
        </span>
      </div>
    </header>
  )
}
