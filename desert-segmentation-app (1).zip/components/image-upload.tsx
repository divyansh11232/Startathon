"use client"

import { useCallback, useState } from "react"
import { Upload, X, ImageIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ImageUploadProps {
  onFileSelect: (file: File) => void
  selectedFile: File | null
  previewUrl: string | null
  onClear: () => void
  disabled?: boolean
}

export function ImageUpload({
  onFileSelect,
  selectedFile,
  previewUrl,
  onClear,
  disabled = false,
}: ImageUploadProps) {
  const [isDragging, setIsDragging] = useState(false)

  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault()
      setIsDragging(false)
      if (disabled) return
      const file = e.dataTransfer.files[0]
      if (file && file.type.startsWith("image/")) {
        onFileSelect(file)
      }
    },
    [onFileSelect, disabled]
  )

  const handleDragOver = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault()
      if (!disabled) setIsDragging(true)
    },
    [disabled]
  )

  const handleDragLeave = useCallback(() => {
    setIsDragging(false)
  }, [])

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (file && file.type.startsWith("image/")) {
        onFileSelect(file)
      }
    },
    [onFileSelect]
  )

  if (previewUrl && selectedFile) {
    return (
      <div className="relative rounded-xl overflow-hidden border border-border bg-card">
        <div className="relative aspect-video flex items-center justify-center bg-background/50">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={previewUrl}
            alt="Uploaded desert terrain"
            className="max-h-full max-w-full object-contain"
          />
        </div>
        <div className="flex items-center justify-between px-4 py-3 border-t border-border bg-card">
          <div className="flex items-center gap-3">
            <ImageIcon className="size-4 text-primary" />
            <div>
              <p className="text-sm font-medium text-foreground truncate max-w-[200px] md:max-w-[300px]">
                {selectedFile.name}
              </p>
              <p className="text-xs text-muted-foreground">
                {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={onClear}
            disabled={disabled}
            aria-label="Remove uploaded image"
          >
            <X className="size-4" />
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      className={cn(
        "relative flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 md:p-12 transition-all duration-300 cursor-pointer",
        isDragging
          ? "border-primary bg-primary/5 scale-[1.01]"
          : "border-border hover:border-primary/50 hover:bg-accent/30",
        disabled && "opacity-50 cursor-not-allowed"
      )}
    >
      <input
        type="file"
        accept="image/*"
        onChange={handleFileInput}
        disabled={disabled}
        className="absolute inset-0 opacity-0 cursor-pointer disabled:cursor-not-allowed"
        aria-label="Upload an image file"
      />
      <div className="flex flex-col items-center gap-4 text-center">
        <div className="flex items-center justify-center size-16 rounded-full bg-primary/10 border border-primary/20">
          <Upload className="size-7 text-primary" />
        </div>
        <div>
          <p className="text-base font-medium text-foreground">
            Drop your desert image here
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            or click to browse files
          </p>
        </div>
        <p className="text-xs text-muted-foreground/70">
          Supports JPG, PNG, WEBP
        </p>
      </div>
    </div>
  )
}
