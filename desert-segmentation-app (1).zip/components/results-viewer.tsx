"use client"

import { useState } from "react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Layers, Image as ImageIcon, Blend } from "lucide-react"

interface ResultsViewerProps {
  originalUrl: string
  maskUrl: string
  overlayUrl: string
}

export function ResultsViewer({
  originalUrl,
  maskUrl,
  overlayUrl,
}: ResultsViewerProps) {
  const [opacity, setOpacity] = useState([60])

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <Tabs defaultValue="side-by-side" className="gap-0">
        <div className="border-b border-border px-4 py-3">
          <TabsList className="bg-muted/50">
            <TabsTrigger value="side-by-side" className="gap-1.5">
              <Layers className="size-3.5" />
              <span className="hidden sm:inline">Compare</span>
            </TabsTrigger>
            <TabsTrigger value="mask" className="gap-1.5">
              <ImageIcon className="size-3.5" />
              <span className="hidden sm:inline">Mask</span>
            </TabsTrigger>
            <TabsTrigger value="overlay" className="gap-1.5">
              <Blend className="size-3.5" />
              <span className="hidden sm:inline">Overlay</span>
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="side-by-side" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border">
            <div className="bg-background/50 p-1">
              <div className="relative">
                <span className="absolute top-2 left-2 z-10 bg-background/80 backdrop-blur-sm text-xs font-medium text-foreground px-2 py-1 rounded-md border border-border">
                  Original
                </span>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={originalUrl}
                  alt="Original desert terrain image"
                  className="w-full aspect-video object-contain rounded-lg"
                />
              </div>
            </div>
            <div className="bg-background/50 p-1">
              <div className="relative">
                <span className="absolute top-2 left-2 z-10 bg-background/80 backdrop-blur-sm text-xs font-medium text-foreground px-2 py-1 rounded-md border border-border">
                  Segmentation Mask
                </span>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={maskUrl}
                  alt="AI-generated segmentation mask of terrain classes"
                  className="w-full aspect-video object-contain rounded-lg"
                />
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="mask" className="mt-0">
          <div className="p-1 bg-background/50">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={maskUrl}
              alt="AI-generated segmentation mask of terrain classes"
              className="w-full aspect-video object-contain rounded-lg"
            />
          </div>
        </TabsContent>

        <TabsContent value="overlay" className="mt-0">
          <div className="p-1 bg-background/50">
            <div className="relative">
              <div className="relative rounded-lg overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={originalUrl}
                  alt="Original desert terrain"
                  className="w-full aspect-video object-contain"
                />
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={maskUrl}
                  alt="Segmentation mask overlay"
                  className="absolute inset-0 w-full h-full object-contain"
                  style={{ opacity: opacity[0] / 100 }}
                />
              </div>
            </div>
            <div className="flex items-center gap-4 px-4 py-3 border-t border-border bg-card mt-1 rounded-b-lg">
              <span className="text-xs text-muted-foreground shrink-0 w-24">
                Mask Opacity
              </span>
              <Slider
                value={opacity}
                onValueChange={setOpacity}
                min={0}
                max={100}
                step={1}
                className="flex-1"
                aria-label="Adjust mask overlay opacity"
              />
              <span className="text-xs font-mono text-foreground w-10 text-right">
                {opacity[0]}%
              </span>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
