"use client"

import { useState, useCallback } from "react"
import { toast } from "sonner"
import { Loader2, Scan, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { AppHeader } from "@/components/app-header"
import { ImageUpload } from "@/components/image-upload"
import { ResultsViewer } from "@/components/results-viewer"
import { TerrainLegend } from "@/components/terrain-legend"

interface PredictionResult {
  mask_url: string
  overlay_url: string
}

export default function Home() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [result, setResult] = useState<PredictionResult | null>(null)

  const handleFileSelect = useCallback((file: File) => {
    setSelectedFile(file)
    setPreviewUrl(URL.createObjectURL(file))
    setResult(null)
  }, [])

  const handleClear = useCallback(() => {
    if (previewUrl) URL.revokeObjectURL(previewUrl)
    setSelectedFile(null)
    setPreviewUrl(null)
    setResult(null)
  }, [previewUrl])

  const handleRunSegmentation = useCallback(async () => {
    if (!selectedFile) return

    setIsProcessing(true)
    toast.info("Running segmentation analysis...")

    try {
      const formData = new FormData()
      formData.append("file", selectedFile)

      const response = await fetch("/api/predict", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => null)
        throw new Error(
          errorData?.error || `Server error: ${response.status}`
        )
      }

      const data = await response.json()

      setResult({
        mask_url: `/api/image?path=${encodeURIComponent(data.mask_url)}`,
        overlay_url: `/api/image?path=${encodeURIComponent(data.overlay_url)}`,
      })

      toast.success("Segmentation complete!")
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "An unexpected error occurred"
      toast.error(`Segmentation failed: ${message}`)
    } finally {
      setIsProcessing(false)
    }
  }, [selectedFile])

  const handleReset = useCallback(() => {
    handleClear()
  }, [handleClear])

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <AppHeader />

      <main className="flex-1 max-w-6xl mx-auto w-full px-4 md:px-6 py-6 md:py-10">
        <div className="flex flex-col gap-6 lg:flex-row">
          {/* Left column - Upload & Controls */}
          <div className="flex flex-col gap-4 lg:w-[380px] shrink-0">
            <div>
              <h2 className="text-sm font-semibold text-foreground mb-1">
                Upload Image
              </h2>
              <p className="text-xs text-muted-foreground mb-3">
                Select a desert terrain image for analysis
              </p>
              <ImageUpload
                onFileSelect={handleFileSelect}
                selectedFile={selectedFile}
                previewUrl={previewUrl}
                onClear={handleClear}
                disabled={isProcessing}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-2">
              <Button
                onClick={handleRunSegmentation}
                disabled={!selectedFile || isProcessing}
                className="w-full h-11 text-sm font-semibold"
                size="lg"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Scan className="size-4" />
                    Run Segmentation
                  </>
                )}
              </Button>

              {result && (
                <Button
                  variant="outline"
                  onClick={handleReset}
                  className="w-full"
                >
                  <RotateCcw className="size-4" />
                  New Analysis
                </Button>
              )}
            </div>

            {/* Terrain Legend */}
            <TerrainLegend />

            {/* Processing indicator */}
            {isProcessing && (
              <div className="rounded-xl border border-primary/20 bg-primary/5 p-4">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="size-2.5 rounded-full bg-primary animate-pulse" />
                    <div className="absolute inset-0 size-2.5 rounded-full bg-primary animate-ping opacity-50" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      Analyzing terrain...
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Running DeepLabV3 segmentation model
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right column - Results */}
          <div className="flex-1 min-w-0">
            {result && previewUrl ? (
              <div className="flex flex-col gap-4">
                <div>
                  <h2 className="text-sm font-semibold text-foreground mb-1">
                    Segmentation Results
                  </h2>
                  <p className="text-xs text-muted-foreground mb-3">
                    Compare the original image with the predicted segmentation
                  </p>
                </div>
                <ResultsViewer
                  originalUrl={previewUrl}
                  maskUrl={result.mask_url}
                  overlayUrl={result.overlay_url}
                />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full min-h-[400px] rounded-xl border border-dashed border-border bg-card/30">
                <div className="flex flex-col items-center gap-4 text-center px-6">
                  <div className="flex items-center justify-center size-20 rounded-full bg-muted/50">
                    <Scan className="size-8 text-muted-foreground/50" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      No results yet
                    </p>
                    <p className="text-xs text-muted-foreground/70 mt-1 max-w-[280px]">
                      Upload a desert terrain image and run segmentation to see
                      AI-predicted terrain classes
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-4">
        <div className="max-w-6xl mx-auto px-4 md:px-6 flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            Desert Semantic Segmentation AI
          </p>
          <p className="text-xs text-muted-foreground font-mono">
            DeepLabV3 ResNet-50 &middot; 10 Classes
          </p>
        </div>
      </footer>
    </div>
  )
}
