"use client"

const TERRAIN_CLASSES = [
  { name: "Background", color: "rgb(0, 0, 0)" },
  { name: "Road", color: "rgb(128, 64, 128)" },
  { name: "Sand", color: "rgb(244, 35, 232)" },
  { name: "Rock", color: "rgb(70, 70, 70)" },
  { name: "Wall", color: "rgb(102, 102, 156)" },
  { name: "Gravel", color: "rgb(190, 153, 153)" },
  { name: "Infrastructure", color: "rgb(153, 153, 153)" },
  { name: "Sign", color: "rgb(250, 170, 30)" },
  { name: "Vegetation", color: "rgb(220, 220, 0)" },
  { name: "Terrain", color: "rgb(107, 142, 35)" },
]

export function TerrainLegend() {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <h3 className="text-sm font-semibold text-foreground mb-3">
        Terrain Classes
      </h3>
      <div className="grid grid-cols-2 gap-2">
        {TERRAIN_CLASSES.map((cls) => (
          <div key={cls.name} className="flex items-center gap-2.5">
            <span
              className="inline-block size-3 rounded-sm shrink-0 border border-foreground/10"
              style={{ backgroundColor: cls.color }}
              aria-hidden="true"
            />
            <span className="text-xs text-muted-foreground">{cls.name}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
